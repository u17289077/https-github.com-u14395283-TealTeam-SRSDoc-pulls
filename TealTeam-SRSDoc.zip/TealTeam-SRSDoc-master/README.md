# TealTeam-SRSDoc
This is the main repository for the Teal team's COS301/COS730 Software Requirements documentation (Phase 1 of the class project).
